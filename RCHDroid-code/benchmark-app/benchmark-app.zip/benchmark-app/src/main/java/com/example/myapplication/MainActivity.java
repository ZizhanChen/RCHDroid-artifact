package com.example.myapplication;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends Activity {
    private ImageView mImageView1;
    private ImageView mImageView2;
    private ImageView mImageView3;
    private ImageView mImageView4;
    private ImageView mImageView5;
    private ImageView mImageView6;
    private ImageView mImageView7;
    private ImageView mImageView8;
    private ImageView mImageView9;
    private ImageView mImageView10;
    private ImageView mImageView11;
    private ImageView mImageView12;
    private ImageView mImageView13;
    private ImageView mImageView14;
    private ImageView mImageView15;
    private ImageView mImageView16;
    //private ImageView mImageView17;
    //private ImageView mImageView18;
    //private ImageView mImageView19;
    //private ImageView mImageView20;
    //private ImageView mImageView21;
    //private ImageView mImageView22;
    //private ImageView mImageView23;
    //private ImageView mImageView24;
    //private ImageView mImageView25;
    //private ImageView mImageView26;
    //private ImageView mImageView27;
    //private ImageView mImageView28;
    //private ImageView mImageView29;
    //private ImageView mImageView30;
    //private ImageView mImageView31;
    //private ImageView mImageView32;

    private final String TAG = "MainActivity";
    private PhotoCycler photoCycler;
    private Button mButton;
    private ProgressDialog dialog ;

    Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    int result = (int) msg.obj;
                    long now = SystemClock.uptimeMillis();
                    Log.e(TAG, "[zizhan] Asynctask migration start at [" + now + "]");
                    mImageView1.setImageResource(result);
                    mImageView2.setImageResource(result);
                    mImageView3.setImageResource(result);
                    mImageView4.setImageResource(result);
                    mImageView5.setImageResource(result);
                    mImageView6.setImageResource(result);
                    mImageView7.setImageResource(result);
                    mImageView8.setImageResource(result);
                    mImageView9.setImageResource(result);
                    mImageView10.setImageResource(result);
                    mImageView11.setImageResource(result);
                    mImageView12.setImageResource(result);
                    mImageView13.setImageResource(result);
                    mImageView14.setImageResource(result);
                    mImageView15.setImageResource(result);
                    mImageView16.setImageResource(result);
                    //mImageView17.setImageResource(result);
                    //mImageView18.setImageResource(result);
                    //mImageView19.setImageResource(result);
                    //mImageView20.setImageResource(result);
                    //mImageView21.setImageResource(result);
                    //mImageView22.setImageResource(result);
                    //mImageView23.setImageResource(result);
                    //mImageView24.setImageResource(result);
                    //mImageView25.setImageResource(result);
                    //mImageView26.setImageResource(result);
                    //mImageView27.setImageResource(result);
                    //mImageView28.setImageResource(result);
                    //mImageView29.setImageResource(result);
                    //mImageView30.setImageResource(result);
                    //mImageView31.setImageResource(result);
                    //mImageView32.setImageResource(result);
                    now = SystemClock.uptimeMillis();
                    Log.e(TAG, "[zizhan] Asynctask migration end at [" + now + "]");
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mImageView1 = (ImageView) findViewById(R.id.imageView1);
        mImageView2 = (ImageView) findViewById(R.id.imageView2);
        mImageView3 = (ImageView) findViewById(R.id.imageView3);
        mImageView4 = (ImageView) findViewById(R.id.imageView4);
        mImageView5 = (ImageView) findViewById(R.id.imageView5);
        mImageView6 = (ImageView) findViewById(R.id.imageView6);
        mImageView7 = (ImageView) findViewById(R.id.imageView7);
        mImageView8 = (ImageView) findViewById(R.id.imageView8);
        mImageView9 = (ImageView) findViewById(R.id.imageView9);
        mImageView10 = (ImageView) findViewById(R.id.imageView10);
        mImageView11 = (ImageView) findViewById(R.id.imageView11);
        mImageView12 = (ImageView) findViewById(R.id.imageView12);
        mImageView13 = (ImageView) findViewById(R.id.imageView13);
        mImageView14 = (ImageView) findViewById(R.id.imageView14);
        mImageView15 = (ImageView) findViewById(R.id.imageView15);
        mImageView16 = (ImageView) findViewById(R.id.imageView16);
        //mImageView17 = (ImageView) findViewById(R.id.imageView17);
        //mImageView18 = (ImageView) findViewById(R.id.imageView18);
        //mImageView19 = (ImageView) findViewById(R.id.imageView19);
        //mImageView20 = (ImageView) findViewById(R.id.imageView20);
        //mImageView21 = (ImageView) findViewById(R.id.imageView21);
        //mImageView22 = (ImageView) findViewById(R.id.imageView22);
        //mImageView23 = (ImageView) findViewById(R.id.imageView23);
        //mImageView24 = (ImageView) findViewById(R.id.imageView24);
        //mImageView25 = (ImageView) findViewById(R.id.imageView25);
        //mImageView26 = (ImageView) findViewById(R.id.imageView26);
        //mImageView27 = (ImageView) findViewById(R.id.imageView27);
        //mImageView28 = (ImageView) findViewById(R.id.imageView28);
        //mImageView29 = (ImageView) findViewById(R.id.imageView29);
        //mImageView30 = (ImageView) findViewById(R.id.imageView30);
        //mImageView31 = (ImageView) findViewById(R.id.imageView31);
        //mImageView32 = (ImageView) findViewById(R.id.imageView32);

        //Log.d(TAG, "onCreate called, mImageView is set to [" + mImageView + "]");
        photoCycler = new PhotoCycler();

        mImageView1.setImageResource(photoCycler.next());
        mImageView2.setImageResource(photoCycler.next());
        mImageView3.setImageResource(photoCycler.next());
        mImageView4.setImageResource(photoCycler.next());
        mImageView5.setImageResource(photoCycler.next());
        mImageView6.setImageResource(photoCycler.next());
        mImageView7.setImageResource(photoCycler.next());
        mImageView8.setImageResource(photoCycler.next());
        mImageView9.setImageResource(photoCycler.next());
        mImageView10.setImageResource(photoCycler.next());
        mImageView11.setImageResource(photoCycler.next());
        mImageView12.setImageResource(photoCycler.next());
        mImageView13.setImageResource(photoCycler.next());
        mImageView14.setImageResource(photoCycler.next());
        mImageView15.setImageResource(photoCycler.next());
        mImageView16.setImageResource(photoCycler.next());
        //mImageView17.setImageResource(photoCycler.next());
        //mImageView18.setImageResource(photoCycler.next());
        //mImageView19.setImageResource(photoCycler.next());
        //mImageView20.setImageResource(photoCycler.next());
        //mImageView21.setImageResource(photoCycler.next());
        //mImageView22.setImageResource(photoCycler.next());
        //mImageView23.setImageResource(photoCycler.next());
        //mImageView24.setImageResource(photoCycler.next());
        //mImageView25.setImageResource(photoCycler.next());
        //mImageView26.setImageResource(photoCycler.next());
        //mImageView27.setImageResource(photoCycler.next());
        //mImageView28.setImageResource(photoCycler.next());
        //mImageView29.setImageResource(photoCycler.next());
        //mImageView30.setImageResource(photoCycler.next());
        //mImageView31.setImageResource(photoCycler.next());
        //mImageView32.setImageResource(photoCycler.next());


        dialog = new ProgressDialog(this);
        dialog.setTitle("Download");
        dialog.setMessage("Waiting···");
        dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        dialog.setCancelable(false);

        mButton = (Button) findViewById(R.id.button);
        mButton.setText("Next");
        mButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        new Thread(new Runnable() {
                            public void run() {
                                try {
                                    int progress_value = 0;
                                    for (int i=0; i<5; i++){
                                        Thread.sleep(1000);
                                        progress_value+=20;
                                        Log.d(TAG, "waiting.....progress[" + progress_value + "]");
                                    }
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                int result = photoCycler.next();
                                Message message = mHandler.obtainMessage();
                                message.what = 1;
                                message.obj = result;
                                mHandler.sendMessage(message);
                            }
                        }).start();
                    }
                }
        );

        /*
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "Switching image");
                AsyncTask<String,Integer,Integer> asyncTask = new AsyncTask<String, Integer, Integer>() {


                    @Override
                    protected void onPreExecute() {
                        super.onPreExecute();
                        //dialog.setProgress(0);
                        //dialog.show();
                    }

                    @Override
                    protected Integer doInBackground(String... params) {
                        try {
                            int progress_value = 0;
                            for (int i=0; i<5; i++){
                                Thread.sleep(1000);
                                progress_value+=20;
                                publishProgress(progress_value);
                                Log.d(TAG, "waiting.....progress[" + progress_value + "]");
                            }
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return photoCycler.next();
                    }
                    @Override

                    protected void onProgressUpdate(Integer... values) {
                        // TODO Auto-generated method stub
                        super.onProgressUpdate(values);
                        //    更新ProgressDialog的进度条
                        //dialog.setProgress(values[0]);
                    }

                    @Override
                    protected void onPostExecute(Integer resID) {
                        mImageView.setImageResource(resID);
                        Log.d(TAG, "Image switched for mImageView [" + mImageView + "] to resID [" + resID + "]");
                        //dialog.dismiss();
                    }
                };
                asyncTask.execute("http://example.com/image.png");
            }
        });*/

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mImageView1 = null;
        mImageView2 = null;
        mImageView3 = null;
        mImageView4 = null;
        mImageView5 = null;
        mImageView6 = null;
        mImageView7 = null;
        mImageView8 = null;
        mImageView9 = null;
        mImageView10 = null;
        mImageView11 = null;
        mImageView12 = null;
        mImageView13 = null;
        mImageView14 = null;
        mImageView15 = null;
        mImageView16 = null;
        //mImageView17 = null;
        //mImageView18 = null;
        //mImageView19 = null;
        //mImageView20 = null;
        //mImageView21 = null;
        //mImageView22 = null;
        //mImageView23 = null;
        //mImageView24 = null;
        //mImageView25 = null;
        //mImageView26 = null;
        //mImageView27 = null;
        //mImageView28 = null;
        //mImageView29 = null;
        //mImageView30 = null;
        //mImageView31 = null;
        //mImageView32 = null;
    }
}
