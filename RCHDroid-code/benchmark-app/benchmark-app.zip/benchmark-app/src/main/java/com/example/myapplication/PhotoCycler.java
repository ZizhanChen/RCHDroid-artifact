package com.example.myapplication;

/**
 * Created by graham on 11/22/15.
 */
public class PhotoCycler {
    private int[] photoIds = new int[] { R.drawable.cat1, R.drawable.cat2, R.drawable.cat3 };

    private int cursor = -1;

    public int next() {
        cursor++;
        if (cursor >= photoIds.length) {
            cursor = 0;
        }

        return photoIds[cursor];
    }
}
